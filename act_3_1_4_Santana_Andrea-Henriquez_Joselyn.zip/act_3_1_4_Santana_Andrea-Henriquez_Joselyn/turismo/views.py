from django.shortcuts import render
from PIL import Image
# Create your views here.


def index(request):
    img = Image.open("C:\\Users\jossh\\OneDrive\\Escritorio\\act2\\turismo\\static\\img\\grecia-tur.jpeg")
    img = img.resize((1380,768))
    nueva_imagen = "fondo.png"
    img = img.save(f"C:\\Users\jossh\\OneDrive\\Escritorio\\act2\\turismo\\static\\img\\{nueva_imagen}")
    context = {"nueva_imagen": nueva_imagen}
    return render(request, 'turismo/index.html', context)